create definer = root@localhost trigger update_balance_trigger
    after update
    on transactions
    for each row
BEGIN
  IF NEW.status = 'successful' AND OLD.status = 'pending' AND OLD.transactionType = 'deposit' THEN
      UPDATE users
      SET balance = balance + OLD.amount
      WHERE id = OLD.userId;
  ELSEIF NEW.status = 'failed' AND OLD.status = 'pending' AND OLD.transactionType = 'withdrawal' THEN
      UPDATE users
      SET balance = balance + OLD.amount
      WHERE id = OLD.userId;    
  END IF;
END;

