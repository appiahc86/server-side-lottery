create definer = root@localhost trigger update_winners_balance_trigger
    after insert
    on winners
    for each row
BEGIN
      UPDATE users
      SET balance = balance + NEW.amountWon
      WHERE id = New.userId;
END;

